package com.example.douyincommenthelper

internal object ScanState {
    const val PREFS = "comment_scan_state"
    const val RUNNING = "running"
    const val KEYWORDS = "keywords"
    const val STATUS = "status"
    // 每次用户开始、继续或停止时递增；服务据此废弃旧滚动任务。
    const val CONTROL_VERSION = "control_version"
    const val STATUS_STARTING = "等待识别评论列表"
    const val STATUS_STOPPED = "已停止筛选"
    const val STATUS_HIT = "找到关键词，已立即停止。请查看当前评论。"
    const val STATUS_NO_CONTAINER = "无法可靠识别评论列表，已暂停；请确认评论区已打开。"
    const val STATUS_CANNOT_SCROLL = "无法确认还能否继续翻页，已暂停；请手动检查评论区。"
    const val STATUS_NO_PROGRESS = "滚动后评论内容没有变化，已安全暂停；请手动检查评论区。"
    const val STATUS_NO_KEYWORDS = "请先设置至少一个关键词。"
    const val STATUS_WRONG_APP = "请先在抖音手动打开视频评论区。"
}
