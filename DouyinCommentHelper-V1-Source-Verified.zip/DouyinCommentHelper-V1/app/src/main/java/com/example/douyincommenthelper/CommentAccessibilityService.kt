package com.example.douyincommenthelper

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.graphics.Rect
import java.util.Locale

class CommentAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var scrollPending = false
    private var generation = 0
    private var lastActionAt = 0L
    private var observedControlVersion = -1
    private var previousVisibleText: String? = null
    private var pendingContinue: Runnable? = null

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        if (!isTargetPackage(pkg)) return
        val prefs = getSharedPreferences(ScanState.PREFS, MODE_PRIVATE)
        // 用户每次点开始/继续/停止都会改变控制版本。版本变化时先废弃旧回调，
        // 避免手动停止后旧的 scrollPending 卡住下一次开始。
        val controlVersion = prefs.getInt(ScanState.CONTROL_VERSION, 0)
        if (controlVersion != observedControlVersion) {
            observedControlVersion = controlVersion
            generation++
            pendingContinue?.let { handler.removeCallbacks(it) }
            pendingContinue = null
            scrollPending = false
            previousVisibleText = null
        }
        if (!prefs.getBoolean(ScanState.RUNNING, false)) return
        if (!scrollPending) scanAndMaybeScroll(generation)
    }

    override fun onInterrupt() { stopWithStatus(ScanState.STATUS_STOPPED) }

    override fun onDestroy() {
        pendingContinue?.let { handler.removeCallbacks(it) }
        pendingContinue = null
        super.onDestroy()
    }

    private fun scanAndMaybeScroll(expectedGeneration: Int) {
        if (expectedGeneration != generation) return
        val prefs = getSharedPreferences(ScanState.PREFS, MODE_PRIVATE)
        if (!prefs.getBoolean(ScanState.RUNNING, false)) return
        val keywords = prefs.getString(ScanState.KEYWORDS, "").orEmpty()
            .split(',', '，', '\n')
            .map { it.trim().lowercase(Locale.ROOT) }
            .filter { it.isNotEmpty() }
        if (keywords.isEmpty()) { stopWithStatus(ScanState.STATUS_NO_KEYWORDS); return }

        val root = rootInActiveWindow ?: run { pauseWithStatus(ScanState.STATUS_NO_CONTAINER); return }
        val container = findVerifiedCommentContainer(root)
        if (container == null) { pauseWithStatus(ScanState.STATUS_NO_CONTAINER); return }

        val comments = ArrayList<String>()
        collectTextInside(container, comments)
        val snapshot = comments.joinToString("\u001f")
        // 不把“滚动动作返回 true”当成列表确实前进的证据。
        // 连续两次看到完全相同的可见文本时安全暂停，不误报已经到底。
        if (previousVisibleText != null && previousVisibleText == snapshot) {
            pauseWithStatus(ScanState.STATUS_NO_PROGRESS)
            return
        }
        previousVisibleText = snapshot
        val hit = comments.firstOrNull { text ->
            val normalized = text.lowercase(Locale.ROOT)
            keywords.any { key -> normalized.contains(key) }
        }
        if (hit != null) {
            // 先使扫描代次失效，再清除队列；任何旧回调都无法继续滚动。
            stopWithStatus(ScanState.STATUS_HIT)
            return
        }

        if (scrollPending || expectedGeneration != generation) return
        val now = System.currentTimeMillis()
        if (now - lastActionAt < 650) return
        lastActionAt = now
        scrollPending = true
        val didScroll = container.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
        if (!didScroll) {
            scrollPending = false
            pauseWithStatus(ScanState.STATUS_CANNOT_SCROLL)
            return
        }
        // 仅在刚才确认的评论列表节点上执行滚动；没有任何全屏手势。
        val callbackGeneration = expectedGeneration
        val callback = Runnable {
            if (callbackGeneration == generation) {
                scrollPending = false
                pendingContinue = null
                scanAndMaybeScroll(callbackGeneration)
            }
        }
        pendingContinue = callback
        handler.postDelayed(callback, 850)
    }

    /**
     * 保守识别：只接受可滚动、resource-id 明确含 comment 的节点，且节点位于屏幕下半部。
     * 不使用“任意 RecyclerView”兜底，避免把视频流当成评论列表。
     */
    private fun findVerifiedCommentContainer(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val candidates = ArrayList<AccessibilityNodeInfo>()
        collectScrollableCommentNodes(root, candidates)
        if (candidates.size != 1) return null
        val candidate = candidates[0]
        val bounds = Rect()
        candidate.getBoundsInScreen(bounds)
        val height = resources.displayMetrics.heightPixels
        if (bounds.isEmpty || bounds.bottom < height * 0.55f || bounds.height() < height * 0.18f) return null
        return candidate
    }

    private fun collectScrollableCommentNodes(node: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>) {
        val id = node.viewIdResourceName.orEmpty().lowercase(Locale.ROOT)
        if (node.isVisibleToUser && node.isScrollable && id.contains("comment")) out.add(node)
        for (i in 0 until node.childCount) node.getChild(i)?.let { child -> collectScrollableCommentNodes(child, out) }
    }

    private fun collectTextInside(node: AccessibilityNodeInfo, out: MutableList<String>) {
        if (!node.isVisibleToUser) return
        val text = node.text?.toString()?.trim().orEmpty()
        val desc = node.contentDescription?.toString()?.trim().orEmpty()
        if (text.isNotEmpty()) out.add(text)
        if (desc.isNotEmpty() && desc != text) out.add(desc)
        for (i in 0 until node.childCount) node.getChild(i)?.let { child -> collectTextInside(child, out) }
    }

    private fun stopWithStatus(status: String) {
        generation++
        scrollPending = false
        pendingContinue?.let { handler.removeCallbacks(it) }
        pendingContinue = null
        getSharedPreferences(ScanState.PREFS, MODE_PRIVATE).edit()
            .putBoolean(ScanState.RUNNING, false)
            .putString(ScanState.STATUS, status)
            .apply()
    }

    private fun pauseWithStatus(status: String) {
        // 暂停与停止相同：不自动恢复，不发起任何滑动；需用户重新点开始。
        stopWithStatus(status)
    }

    private fun isTargetPackage(pkg: String): Boolean =
        pkg == "com.ss.android.ugc.aweme" || pkg == "com.zhiliaoapp.musically"
}
