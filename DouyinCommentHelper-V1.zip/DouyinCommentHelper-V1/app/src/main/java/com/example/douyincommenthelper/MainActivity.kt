package com.example.douyincommenthelper

import android.app.Activity
import android.content.Intent
import android.content.ClipboardManager
import android.content.ClipData
import android.os.Bundle
import android.os.Build
import android.provider.Settings
import android.net.Uri
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var keywordInput: EditText
    private lateinit var statusView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences(ScanState.PREFS, MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(TextView(this).apply {
            text = "抖音评论筛选助手 V1\n先手动打开抖音视频的评论区，再回来设置关键词并开始。"
            textSize = 18f
        }, matchParams())
        keywordInput = EditText(this).apply {
            hint = "输入关键词，多个关键词用逗号分隔"
            setText(prefs.getString(ScanState.KEYWORDS, "兼职,联系方式,怎么联系") ?: "")
            minLines = 2
        }
        root.addView(keywordInput, matchParams())
        val save = Button(this).apply {
            text = "保存关键词"
            setOnClickListener {
                prefs.edit().putString(ScanState.KEYWORDS, keywordInput.text.toString()).apply()
                setStatus("关键词已保存")
            }
        }
        root.addView(save, matchParams())
        val accessibility = Button(this).apply {
            text = "打开无障碍设置"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        root.addView(accessibility, matchParams())
        root.addView(Button(this).apply {
            text = "复制识别诊断信息"
            setOnClickListener {
                val diagnostic = prefs.getString(ScanState.DIAGNOSTICS, "").orEmpty()
                if (diagnostic.isBlank()) {
                    Toast.makeText(this@MainActivity, "还没有诊断信息。请先在评论区尝试开始筛选。", Toast.LENGTH_LONG).show()
                } else {
                    val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("评论助手诊断（不含评论文字）", diagnostic))
                    Toast.makeText(this@MainActivity, "已复制结构诊断信息，可粘贴到聊天中。", Toast.LENGTH_LONG).show()
                }
            }
        }, matchParams())
        root.addView(Button(this).apply {
            text = "开启悬浮控制窗"
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this@MainActivity)) {
                    val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                    startActivity(intent)
                    setStatus("请允许显示在其他应用上层，再返回点击开启悬浮控制窗")
                } else {
                    startService(Intent(this@MainActivity, FloatingControlService::class.java))
                    setStatus("悬浮控制窗已请求开启")
                }
            }
        }, matchParams())
        root.addView(Button(this).apply {
            text = "关闭悬浮控制窗"
            setOnClickListener {
                stopService(Intent(this@MainActivity, FloatingControlService::class.java))
                setStatus("悬浮控制窗已关闭")
            }
        }, matchParams())
        root.addView(Button(this).apply {
            text = "开始筛选（先打开评论区）"
            setOnClickListener {
                prefs.edit().putString(ScanState.KEYWORDS, keywordInput.text.toString())
                    .putBoolean(ScanState.RUNNING, true)
                    .putBoolean(ScanState.CONTINUE_REQUESTED, false)
                    .remove(ScanState.LAST_HIT_TEXT)
                    .putInt(ScanState.CONTROL_VERSION, prefs.getInt(ScanState.CONTROL_VERSION, 0) + 1)
                    .putString(ScanState.STATUS, ScanState.STATUS_STARTING)
                    .apply()
                setStatus("已请求开始。请切回抖音评论区；只有识别到明确的评论列表才会滚动。")
            }
        }, matchParams())
        root.addView(Button(this).apply {
            text = "继续查找下一条"
            setOnClickListener {
                // 命中后由用户手动移开已查看的评论，再点击这里继续。
                // 不自动跳过评论，也不执行任何全屏手势。
                prefs.edit().putBoolean(ScanState.RUNNING, true)
                    .putBoolean(ScanState.CONTINUE_REQUESTED, true)
                    .putInt(ScanState.CONTROL_VERSION, prefs.getInt(ScanState.CONTROL_VERSION, 0) + 1)
                    .putString(ScanState.STATUS, ScanState.STATUS_STARTING).apply()
                setStatus("已请求继续。若上一条命中评论仍在屏幕内，程序会再次暂停；请先手动滚动让它离开可见区域，再点继续。")
            }
        }, matchParams())
        root.addView(Button(this).apply {
            text = "停止筛选"
            setOnClickListener {
                prefs.edit().putBoolean(ScanState.RUNNING, false)
                    .putInt(ScanState.CONTROL_VERSION, prefs.getInt(ScanState.CONTROL_VERSION, 0) + 1)
                    .putString(ScanState.STATUS, ScanState.STATUS_STOPPED).apply()
                setStatus(ScanState.STATUS_STOPPED)
            }
        }, matchParams())
        statusView = TextView(this).apply { textSize = 16f; text = prefs.getString(ScanState.STATUS, "尚未开始") }
        root.addView(statusView, matchParams())
        root.addView(TextView(this).apply {
            textSize = 13f
            text = "安全说明：本版本不使用全屏滑动、不做全屏 OCR。只有系统提供明确的评论列表及评论正文节点时才会扫描；无法区分正文与用户名等信息时会安全暂停。无障碍权限可读取其他应用界面，请只在你理解并信任本程序时开启。"
        }, matchParams())
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        if (::statusView.isInitialized) {
            statusView.text = getSharedPreferences(ScanState.PREFS, MODE_PRIVATE)
                .getString(ScanState.STATUS, "尚未开始")
        }
    }

    private fun setStatus(value: String) { statusView.text = value }
    private fun matchParams() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 14 }
}
