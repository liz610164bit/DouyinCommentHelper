package com.example.douyincommenthelper

internal object ScanState {
    const val PREFS = "comment_scan_state"
    const val RUNNING = "running"
    const val KEYWORDS = "keywords"
    const val STATUS = "status"
    const val DIAGNOSTICS = "diagnostics"
    const val LAST_HIT_TEXT = "last_hit_text"
    const val CONTINUE_REQUESTED = "continue_requested"
    // 每次用户开始、继续或停止时递增；服务据此废弃旧滚动任务。
    const val CONTROL_VERSION = "control_version"
    const val STATUS_STARTING = "等待识别评论列表"
    const val STATUS_STOPPED = "已停止筛选"
    const val STATUS_HIT = "找到关键词，已立即停止。请查看当前评论。"
    const val STATUS_MOVE_PAST_HIT = "上一条命中评论仍在屏幕内。请先手动滚动，直到它离开可见区域，再点继续。"
    const val STATUS_NO_CONTAINER = "无法可靠识别评论列表，已暂停；请确认评论区已打开。"
    const val STATUS_NO_COMMENT_TEXT = "无法可靠区分评论正文与用户名等信息，已暂停；当前版本不会猜测或误报。"
    const val STATUS_CANNOT_SCROLL = "无法确认还能否继续翻页，已暂停；请手动检查评论区。"
    const val STATUS_NO_PROGRESS = "滚动后评论内容没有变化，已安全暂停；请手动检查评论区。"
    const val STATUS_NO_KEYWORDS = "请先设置至少一个关键词。"
    const val STATUS_WRONG_APP = "请先在抖音或抖音火山版手动打开视频评论区。"
}
