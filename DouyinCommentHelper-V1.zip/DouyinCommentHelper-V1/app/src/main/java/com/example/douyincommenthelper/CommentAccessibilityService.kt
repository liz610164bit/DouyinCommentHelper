package com.example.douyincommenthelper

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.graphics.Rect
import java.util.Locale

class CommentAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var scrollPending = false
    private var generation = 0
    private var lastActionAt = 0L
    private var observedControlVersion = -1
    private var previousVisibleText: String? = null
    private var pendingContinue: Runnable? = null

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        if (!isTargetPackage(pkg)) return
        val prefs = getSharedPreferences(ScanState.PREFS, MODE_PRIVATE)
        // 用户每次点开始/继续/停止都会改变控制版本。版本变化时先废弃旧回调，
        // 避免手动停止后旧的 scrollPending 卡住下一次开始。
        val controlVersion = prefs.getInt(ScanState.CONTROL_VERSION, 0)
        if (controlVersion != observedControlVersion) {
            observedControlVersion = controlVersion
            generation++
            pendingContinue?.let { handler.removeCallbacks(it) }
            pendingContinue = null
            scrollPending = false
            previousVisibleText = null
        }
        if (!prefs.getBoolean(ScanState.RUNNING, false)) return
        if (!scrollPending) scanAndMaybeScroll(generation)
    }

    override fun onInterrupt() { stopWithStatus(ScanState.STATUS_STOPPED) }

    override fun onDestroy() {
        pendingContinue?.let { handler.removeCallbacks(it) }
        pendingContinue = null
        super.onDestroy()
    }

    private fun scanAndMaybeScroll(expectedGeneration: Int) {
        if (expectedGeneration != generation) return
        val prefs = getSharedPreferences(ScanState.PREFS, MODE_PRIVATE)
        // 不只依赖无障碍事件同步版本：每次扫描入口都读取最新控制状态。
        val currentVersion = prefs.getInt(ScanState.CONTROL_VERSION, 0)
        if (currentVersion != observedControlVersion) {
            observedControlVersion = currentVersion
            generation++
            pendingContinue?.let { handler.removeCallbacks(it) }
            pendingContinue = null
            scrollPending = false
            previousVisibleText = null
        }
        if (expectedGeneration != generation || !prefs.getBoolean(ScanState.RUNNING, false)) return
        val keywords = prefs.getString(ScanState.KEYWORDS, "").orEmpty()
            .split(',', '，', '\n')
            .map { it.trim().lowercase(Locale.ROOT) }
            .filter { it.isNotEmpty() }
        if (keywords.isEmpty()) { stopWithStatus(ScanState.STATUS_NO_KEYWORDS); return }

        val root = rootInActiveWindow ?: run { pauseWithStatus(ScanState.STATUS_NO_CONTAINER); return }
        // 延迟回调可能在用户切换到其他应用后执行；此时绝不操作任何界面。
        val activePackage = root.packageName?.toString().orEmpty()
        if (!isTargetPackage(activePackage)) {
            pauseWithStatus(ScanState.STATUS_WRONG_APP)
            return
        }
        val container = findVerifiedCommentContainer(root)
        if (container == null) {
            saveSafeDiagnostics(root)
            pauseWithStatus(ScanState.STATUS_NO_CONTAINER)
            return
        }

        // 只读取 resource-id 明确指向“评论正文/内容”的可见文本节点。
        // 不再把容器内所有文字和 contentDescription 混在一起，避免用户名、时间、点赞数误命中。
        val comments = extractCommentBodies(container)
        if (comments == null) {
            saveSafeDiagnostics(root)
            pauseWithStatus(ScanState.STATUS_NO_COMMENT_TEXT)
            return
        }
        val snapshot = comments.joinToString("\u001f")
        if (prefs.getBoolean(ScanState.CONTINUE_REQUESTED, false)) {
            val lastHit = prefs.getString(ScanState.LAST_HIT_TEXT, null)
            if (!lastHit.isNullOrBlank() && comments.any { normalizeForRepeatCheck(it) == normalizeForRepeatCheck(lastHit) }) {
                pauseWithStatus(ScanState.STATUS_MOVE_PAST_HIT)
                return
            }
            prefs.edit().putBoolean(ScanState.CONTINUE_REQUESTED, false)
                .remove(ScanState.LAST_HIT_TEXT).apply()
        }
        // 不把“滚动动作返回 true”当成列表确实前进的证据。
        // 连续两次看到完全相同的可见文本时安全暂停，不误报已经到底。
        if (previousVisibleText != null && previousVisibleText == snapshot) {
            pauseWithStatus(ScanState.STATUS_NO_PROGRESS)
            return
        }
        previousVisibleText = snapshot
        val hit = comments.firstOrNull { text ->
            val normalized = text.lowercase(Locale.ROOT)
            keywords.any { key -> normalized.contains(key) }
        }
        if (hit != null) {
            // 保存命中正文。用户点击继续前必须手动滚动到该正文离开可见区，避免立即重复命中。
            prefs.edit().putString(ScanState.LAST_HIT_TEXT, hit)
                .putBoolean(ScanState.CONTINUE_REQUESTED, false).apply()
            // 先使扫描代次失效，再清除队列；任何旧回调都无法继续滚动。
            stopWithStatus(ScanState.STATUS_HIT)
            return
        }

        if (scrollPending || expectedGeneration != generation) return
        val now = System.currentTimeMillis()
        if (now - lastActionAt < 650) return
        lastActionAt = now
        scrollPending = true
        val didScroll = container.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
        if (!didScroll) {
            scrollPending = false
            pauseWithStatus(ScanState.STATUS_CANNOT_SCROLL)
            return
        }
        // 仅在刚才确认的评论列表节点上执行滚动；没有任何全屏手势。
        val callbackGeneration = expectedGeneration
        val callbackControlVersion = prefs.getInt(ScanState.CONTROL_VERSION, 0)
        val callback = Runnable {
            val latestPrefs = getSharedPreferences(ScanState.PREFS, MODE_PRIVATE)
            val stillCurrent = callbackGeneration == generation &&
                callbackControlVersion == latestPrefs.getInt(ScanState.CONTROL_VERSION, 0) &&
                latestPrefs.getBoolean(ScanState.RUNNING, false)
            scrollPending = false
            pendingContinue = null
            if (stillCurrent) {
                scanAndMaybeScroll(callbackGeneration)
            }
        }
        pendingContinue = callback
        handler.postDelayed(callback, 850)
    }

    /**
     * 保守识别：只接受可滚动、resource-id 明确含 comment 的节点，且节点位于屏幕下半部。
     * 不使用“任意 RecyclerView”兜底，避免把视频流当成评论列表。
     */
    private fun findVerifiedCommentContainer(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val candidates = ArrayList<AccessibilityNodeInfo>()
        collectScrollableCommentNodes(root, candidates)
        if (candidates.size != 1) return null
        val candidate = candidates[0]
        val bounds = Rect()
        candidate.getBoundsInScreen(bounds)
        val height = resources.displayMetrics.heightPixels
        if (bounds.isEmpty || bounds.bottom < height * 0.55f || bounds.height() < height * 0.18f) return null
        return candidate
    }

    private fun collectScrollableCommentNodes(node: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>) {
        val id = node.viewIdResourceName.orEmpty().lowercase(Locale.ROOT)
        if (node.isVisibleToUser && node.isScrollable && id.contains("comment")) out.add(node)
        for (i in 0 until node.childCount) node.getChild(i)?.let { child -> collectScrollableCommentNodes(child, out) }
    }


    /** Store structure only (IDs, classes and bounds); never store comment/user text. */
    private fun saveSafeDiagnostics(root: AccessibilityNodeInfo) {
        val lines = StringBuilder()
        var count = 0
        fun visit(node: AccessibilityNodeInfo, depth: Int) {
            if (count >= 120 || depth > 16) return
            count++
            val bounds = Rect()
            node.getBoundsInScreen(bounds)
            val id = try { node.viewIdResourceName.orEmpty() } catch (_: Exception) { "" }
            val cls = node.className?.toString().orEmpty().substringAfterLast('.')
            lines.append("  ".repeat(depth.coerceAtMost(8)))
                .append(cls).append(" | id=").append(id)
                .append(" | scroll=").append(node.isScrollable)
                .append(" | visible=").append(node.isVisibleToUser)
                .append(" | bounds=").append(bounds.flattenToString())
                .append("\n")
            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { visit(it, depth + 1) }
            }
        }
        visit(root, 0)
        getSharedPreferences(ScanState.PREFS, MODE_PRIVATE).edit()
            .putString(ScanState.DIAGNOSTICS, "package=${root.packageName}\n$lines")
            .apply()
    }

    /**
     * 保守提取评论正文：当前没有真实设备的无障碍节点树可供校准，
     * 因此只接受 resource-id 同时包含 comment 与 content/body/text 的可见文本节点。
     * 无法明确区分正文时返回 null 并暂停，绝不退回“读取容器全部文字”。
     */
    private fun extractCommentBodies(container: AccessibilityNodeInfo): List<String>? {
        val found = LinkedHashSet<String>()
        collectExplicitCommentBodyNodes(container, found)
        return found.toList().takeIf { it.isNotEmpty() }
    }

    private fun collectExplicitCommentBodyNodes(
        node: AccessibilityNodeInfo,
        out: MutableSet<String>
    ) {
        if (!node.isVisibleToUser) return

        val id = node.viewIdResourceName.orEmpty().lowercase(Locale.ROOT)
        val excludedIdParts = listOf("user", "avatar", "author", "name", "time", "date", "like", "reply", "count")
        val looksLikeBody = id.contains("comment") &&
            (id.contains("content") || id.contains("body") || id.contains("text")) &&
            excludedIdParts.none { id.contains(it) }

        if (looksLikeBody) {
            val value = node.text?.toString()?.trim().orEmpty()
            val bounds = Rect()
            node.getBoundsInScreen(bounds)
            if (value.isNotEmpty() && bounds.height() > 0 && bounds.width() > 0) {
                out.add(value)
            }
        }

        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child -> collectExplicitCommentBodyNodes(child, out) }
        }
    }

    private fun normalizeForRepeatCheck(value: String): String =
        value.lowercase(Locale.ROOT).filterNot { it.isWhitespace() || it == '\u200b' || it == '\ufeff' }

    private fun stopWithStatus(status: String) {
        generation++
        scrollPending = false
        pendingContinue?.let { handler.removeCallbacks(it) }
        pendingContinue = null
        getSharedPreferences(ScanState.PREFS, MODE_PRIVATE).edit()
            .putBoolean(ScanState.RUNNING, false)
            .putString(ScanState.STATUS, status)
            .apply()
    }

    private fun pauseWithStatus(status: String) {
        // 暂停与停止相同：不自动恢复，不发起任何滑动；需用户重新点开始。
        stopWithStatus(status)
    }

    private fun isTargetPackage(pkg: String): Boolean =
        pkg == "com.ss.android.ugc.aweme" ||
            pkg == "com.ss.android.ugc.live" ||
            pkg == "com.zhiliaoapp.musically"
}
