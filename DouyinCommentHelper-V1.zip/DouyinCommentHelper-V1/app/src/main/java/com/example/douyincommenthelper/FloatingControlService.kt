package com.example.douyincommenthelper

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/** Small, user-controlled overlay. It never performs gestures itself; it only updates scan state. */
class FloatingControlService : Service() {
    private lateinit var windowManager: WindowManager
    private var panel: View? = null
    private var statusLabel: TextView? = null
    private lateinit var params: WindowManager.LayoutParams

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        buildPanel()
    }

    private fun buildPanel() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 8, 10, 8)
            background = GradientDrawable().apply {
                setColor(0xEE202124.toInt())
                cornerRadius = 18f
            }
        }
        val handle = TextView(this).apply {
            text = "评论助手  ⋮⋮"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 12f
            setPadding(8, 4, 8, 8)
        }
        root.addView(handle)
        statusLabel = TextView(this).apply {
            text = "待命"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 11f
            setPadding(8, 0, 8, 6)
        }
        root.addView(statusLabel)
        statusLabel?.setOnClickListener { refreshStatus() }
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.addView(makeButton("开始", 0xFF2E7D32.toInt()) {
            val prefs = getSharedPreferences(ScanState.PREFS, MODE_PRIVATE)
            prefs.edit().putBoolean(ScanState.RUNNING, true)
                .putBoolean(ScanState.CONTINUE_REQUESTED, false)
                .remove(ScanState.LAST_HIT_TEXT)
                .putInt(ScanState.CONTROL_VERSION, prefs.getInt(ScanState.CONTROL_VERSION, 0) + 1)
                .putString(ScanState.STATUS, ScanState.STATUS_STARTING).apply()
        })
        buttons.addView(makeButton("继续", 0xFF1565C0.toInt()) {
            val prefs = getSharedPreferences(ScanState.PREFS, MODE_PRIVATE)
            prefs.edit().putBoolean(ScanState.RUNNING, true)
                .putBoolean(ScanState.CONTINUE_REQUESTED, true)
                .putInt(ScanState.CONTROL_VERSION, prefs.getInt(ScanState.CONTROL_VERSION, 0) + 1)
                .putString(ScanState.STATUS, "已请求继续查找").apply()
        })
        buttons.addView(makeButton("暂停", 0xFF8D6E63.toInt()) { setRunning(false, "已暂停") })
        buttons.addView(makeButton("停止", 0xFFC62828.toInt()) { setRunning(false, ScanState.STATUS_STOPPED) })
        root.addView(buttons)
        val closeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        closeRow.addView(makeButton("关闭悬浮窗", 0xFF424242.toInt()) { stopSelf() })
        root.addView(closeRow)

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 18
            y = 220
        }
        handle.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var touchX = 0f
            private var touchY = 0f
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x
                        startY = params.y
                        touchX = event.rawX
                        touchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = (startX - (event.rawX - touchX)).toInt()
                        params.y = (startY + (event.rawY - touchY)).toInt()
                        panel?.let { windowManager.updateViewLayout(it, params) }
                        return true
                    }
                    MotionEvent.ACTION_UP -> return true
                }
                return false
            }
        })
        panel = root
        windowManager.addView(root, params)
        refreshStatus()
    }

    private fun makeButton(label: String, color: Int, action: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 11f
        gravity = Gravity.CENTER
        setTextColor(0xFFFFFFFF.toInt())
        setPadding(8, 7, 8, 7)
        background = GradientDrawable().apply {
            setColor(color)
            cornerRadius = 10f
        }
        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        lp.marginEnd = 4
        layoutParams = lp
        setOnClickListener { action(); refreshStatus() }
    }

    private fun setRunning(running: Boolean, status: String) {
        val prefs = getSharedPreferences(ScanState.PREFS, MODE_PRIVATE)
        prefs.edit()
            .putBoolean(ScanState.RUNNING, running)
            .putInt(ScanState.CONTROL_VERSION, prefs.getInt(ScanState.CONTROL_VERSION, 0) + 1)
            .putString(ScanState.STATUS, status)
            .apply()
    }

    private fun refreshStatus() {
        val prefs = getSharedPreferences(ScanState.PREFS, MODE_PRIVATE)
        statusLabel?.text = prefs.getString(ScanState.STATUS, "待命")?.take(28) ?: "待命"
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onDestroy() {
        panel?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
