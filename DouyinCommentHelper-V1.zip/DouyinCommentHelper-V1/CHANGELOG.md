# Changelog

## 1.1 - Source improvement round

- Hardened scan-generation and control-version checks so delayed callbacks cannot restart a stopped or superseded scan.
- Kept scrolling restricted to a single visible, scrollable node whose resource ID explicitly identifies a comment list; no full-screen swipe is used.
- Restricted comment text extraction to visible nodes whose resource IDs explicitly indicate comment content/body/text. If the structure is ambiguous, scanning pauses rather than searching unrelated screen text.
- Added a privacy-safe structure diagnostic capture (node class, resource ID, visibility, scrollability and bounds only; no displayed text).
- Added a draggable floating control panel with start, continue, pause, stop and close controls. It requires the user's Android "display over other apps" permission.
- Added the verified Android package ID for Douyin Volcano Edition (`com.ss.android.ugc.live`).
- Added a continue guard: the previous hit's exact text must no longer be visible before scanning resumes, reducing immediate repeat hits. Identical comments may cause a conservative extra pause.
- Increased app version to 1.1 (versionCode 2).

## Not included / requires device validation

- OCR is not yet integrated. A screenshot OCR fallback must be limited to the actual comment-body rectangles; running OCR across the entire comment panel could mistake usernames, timestamps or controls for comment text. The structure diagnostic is included so the next round can be calibrated against the real OPPO/Douyin accessibility tree.
- Douyin and Volcano Edition layouts, overlay positioning and actual scrolling still require testing on the target phone.
- This source package has not been built with Android Gradle Plugin in this environment. GitHub Actions must confirm the APK build.
